/*package com.tcs.rmg.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "rmg_approver", schema = "rmg_app")
public class RmgDetails {
	
	@Id
	@Column(name = "rmg_id")
	private Integer rmgId;

	public Integer getRmgId() {
		return rmgId;
	}

	public void setRmgId(Integer rmgId) {
		this.rmgId = rmgId;
	}
	
	

}
*/