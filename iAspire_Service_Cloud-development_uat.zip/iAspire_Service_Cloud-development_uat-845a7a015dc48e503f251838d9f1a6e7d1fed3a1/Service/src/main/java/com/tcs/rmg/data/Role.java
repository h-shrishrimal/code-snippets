package com.tcs.rmg.data;

public class Role {

	String role;

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}
	
}
