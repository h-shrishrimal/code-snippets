package com.tcs.rmg.data;

public class ExcitingOpportunitiesCount {
	Integer count;

	public Integer getCount() {
		return count;
	}

	public void setCount(Integer count) {
		this.count = count;
	}
	
}
