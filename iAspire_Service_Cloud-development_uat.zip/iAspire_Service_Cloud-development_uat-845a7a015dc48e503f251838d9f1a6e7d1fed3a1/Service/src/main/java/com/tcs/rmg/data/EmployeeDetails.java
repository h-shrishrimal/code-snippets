package com.tcs.rmg.data;

public class EmployeeDetails {

	private String role;
	private Boolean showExcitingOpportunities;

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public Boolean getShowExcitingOpportunities() {
		return showExcitingOpportunities;
	}

	public void setShowExcitingOpportunities(Boolean showExcitingOpportunities) {
		this.showExcitingOpportunities = showExcitingOpportunities;
	}


}
