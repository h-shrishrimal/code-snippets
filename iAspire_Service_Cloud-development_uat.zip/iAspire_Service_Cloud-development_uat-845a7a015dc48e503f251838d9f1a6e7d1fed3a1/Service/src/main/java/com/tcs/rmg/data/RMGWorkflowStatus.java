package com.tcs.rmg.data;

public enum RMGWorkflowStatus {
	
	OPEN,
	GL_APPROVAL_PENDING,
	GL_REJECTED,
	RMG_APPROVAL_PENDING,
	RMG_APPROVED,
	RMG_REJECTED

}
