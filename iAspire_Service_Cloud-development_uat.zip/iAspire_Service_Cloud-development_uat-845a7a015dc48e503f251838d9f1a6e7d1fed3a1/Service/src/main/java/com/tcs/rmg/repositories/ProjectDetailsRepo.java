package com.tcs.rmg.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import com.tcs.rmg.domain.ProjectDetails;

public interface ProjectDetailsRepo extends JpaRepository<ProjectDetails,Integer>{

}
